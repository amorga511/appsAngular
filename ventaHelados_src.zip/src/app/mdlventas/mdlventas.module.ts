import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { MatFormFieldModule} from '@angular/material/form-field';
import { MatInputModule } from  '@angular/material/input';
import { MatButtonModule} from  '@angular/material/button';
import { MatIconModule} from  '@angular/material/icon';
import { MatDialogModule} from '@angular/material/dialog';
import { MatTableModule} from  '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { MatCheckboxModule } from '@angular/material/checkbox';


import { FacturacionComponent } from './facturacion/facturacion.component';
import { MdlsharedModule } from '../mdlshared/mdlshared.module';
import { AppRoutingModule } from '../app-routing.module';




@NgModule({
  declarations: [
    FacturacionComponent
  ],
  imports: [
    MdlsharedModule,

    BrowserModule,
    HttpClientModule,
    MatCheckboxModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    MatInputModule,
    MatDialogModule,
    MatInputModule,
    MatButtonModule,
    MatTabsModule,
    MatTableModule,
    MatButtonModule,
    MatTableModule,
    MatFormFieldModule
  ]
})
export class MdlventasModule { }
