import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { CookieService } from 'ngx-cookie-service';
import { WsappService } from 'src/app/wsapp.service';

export interface arrItems{
  id_item:string,
  desc_item:string,
  cant:number,
  price:number,
  isv:number,
  arrInv:{}
  numReg:number
}

@Component({
  selector: 'app-facturacion',
  templateUrl: './facturacion.component.html',
  styleUrls: ['./facturacion.component.css']
})



export class FacturacionComponent implements OnInit {

  constructor(private cookSvr: CookieService, private formBuildr: FormBuilder, private app_svr:WsappService) { }

  flag_jarabe1 = false;
  flag_jarabe2 = false;
  flag_jarabe3 = false;
  flag_fruta1 = false;
  flag_fruta2 = false;
  flag_fruta3 = false;
  lecheC = false;
  extralecheC = false;
  extraF = false;
  numItem = 0;
  vVendedor = "";

  fech_facs = new Date();

  vprecio = '999';
  vFormFac!:FormGroup;
  
  datosFactura!:MatTableDataSource<any>;
  tblFacsPrint!:MatTableDataSource<any>;

  displayedColumns:string[] = ["numReg","desc_item", "cant", "price", "subTot"];
  columsFactEmi:string[] = ["id_fac", "fecha", "monto", "print"];
  dtable:arrItems[] = []; //[{id_item:0, desc_item:'xxx', cant:2, price:24, isv:0}];

  vSizes = [{id:110, name:"Tradicional 8oz", price:25}];  
  vExtras = [{id:120, name:"Extra Fruta", price:5}];
  vJarabes = [{id:201, name:"Fresa"}];  
  vFrutas = [{id:301, name:"Melocoton"}];
  dtosTotales = {vndor:"", total:0, efectivo:0, tarjeta:0, subTotExento:0, subTotGrabado:0, subTotExonerado:0, descuento:0, impuesto15:0, impuesto18:0};
  vFacsPrint = [{id:0, fech:'-', amount:0}]
  ngOnInit(): void {
    //this.datosFactura = new MatTableDataSource(this.dtable);
    this.vVendedor = this.cookSvr.get("usr");
    let tDt = new Date();
    tDt.setDate(tDt.getDate()-1);

    this.fech_facs = tDt;

    this.limpiarFact();
    this.showFacs(1);
    
  }


  limpiItems(){

    this.vFormFac = this.formBuildr.group({
      tamanio:['',[Validators.required]],
      price:['',[]],
      jarabe1:['',[]],
      jarabe2:['',[]],
      jarabe3:['',[]],      
      fruta1:['',[]],
      fruta2:['',[]],
      fruta3:['',[]],
      cant:[1, [Validators.required]],
      lechCon:[true, []],      
      extraFruta:['', []],    
      extraLecheCon:['', []]         
    });

    this.flag_jarabe1 = false;
    this.flag_jarabe2 = false;
    this.flag_jarabe3 = false;
    this.flag_fruta1 = false;
    this.flag_fruta2 = false;
    this.flag_fruta3 = false;
    this.lecheC = false;
    this.extralecheC = false;
    this.extraF = false;

    let temp=new Array();
    let temp2=new Array();

    this.app_svr.getProducts({op:101}).subscribe(result=>{
      let x = JSON.stringify(result);
      let vRes = JSON.parse(x);
      temp=new Array();
      temp2=new Array();
      for(let xProd of vRes.datos){
        if(Number(xProd.type)==1){
          temp.push({id:xProd.id, name:xProd.name, price:xProd.price, type:xProd.type});
        }else{
          temp2.push({id:xProd.id, name:xProd.name, price:xProd.price, type:xProd.type});
        }
      }
      this.vSizes = temp;
      this.vExtras = temp2 
    });

    
    this.app_svr.getFrutasJarabes({op:102}).subscribe(result=>{
      let x = JSON.stringify(result);
      let vRes = JSON.parse(x);      
      temp=new Array();
      temp2=new Array();
      for(let xIngr of vRes.datos){
        //console.log(xIngr.type);
        if(xIngr.type=='J'){
          temp.push({id:xIngr.id, name:xIngr.name});
        }else{
          temp2.push({id:xIngr.id, name:xIngr.name});
        }
      }
      this.vJarabes = temp;
      this.vFrutas = temp2  
    });
    


  }

  openDialogMenu(){
    //const dialogRef = this.dialog.open(DialogMenuComponent);

    
    /*dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if(result){
        let temp !: arrItems;   
        temp = {id_item:result.id,desc_item:result.title,cant:result.cant,price:result.price,isv:0, arrInv:[]};
  
        this.dtable.push(temp);
        this.datosFactura = new MatTableDataSource(this.dtable);
  
        this.calculaTotales();
      }  
    });*/
  }

  addItemFact(){
    let temp !: arrItems;   
    let desc = '';
    let arr2 = {};
    let LecheCond = 'S';
    let strLechCon = 'Leche Cond.';
    let vRegN = 0

    vRegN = this.numItem+1;
    this.numItem++;

    //console.log(this.vFormFac.value.lechCon);
    if(this.vFormFac.value.lechCon){
      LecheCond = 'S';
    }else{
      LecheCond = 'N';      
      strLechCon =  '';
    }

    switch(Number(this.vFormFac.value.tamanio)){
      case 110:
        arr2 = {j1:this.vFormFac.value.jarabe1,
        j2:0,
        j3:0,
        f1:0,
        f2:0,
        f3:0,
        lc:LecheCond};
        desc = this.getRaspadoName(this.vFormFac.value.tamanio);
        desc += ' J(' + this.getJarabeName(this.vFormFac.value.jarabe1) + ')';
        desc += ' ' +strLechCon;
      break;

      case 111:
        arr2 = {j1:this.vFormFac.value.jarabe1,
        j2:0,
        j3:0,
        f1:this.vFormFac.value.fruta1,
        f2:0,
        f3:0,
        lc:LecheCond};
        desc = this.getRaspadoName(this.vFormFac.value.tamanio);
        desc += ' J(' + this.getJarabeName(this.vFormFac.value.jarabe1) + ')';
        desc += ' F(' + this.getFrutaName(this.vFormFac.value.fruta1) + ')';
        desc += ' ' +strLechCon;
      break;

      case 112:
        arr2 = {j1:this.vFormFac.value.jarabe1,
        j2:this.vFormFac.value.jarabe2,
        j3:0,
        f1:this.vFormFac.value.fruta1,
        f2:this.vFormFac.value.fruta2,
        f3:0,
        lc:LecheCond};
        desc = this.getRaspadoName(this.vFormFac.value.tamanio);
        desc += ' J(' + this.getJarabeName(this.vFormFac.value.jarabe1);
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta2) + ')';
        desc += ' F(' + this.getFrutaName(this.vFormFac.value.fruta1);        
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta2) + ')';
        desc += ' ' +strLechCon;
      break;

      case 113:
        arr2 = {j1:this.vFormFac.value.jarabe1,
        j2:this.vFormFac.value.jarabe2,
        j3:0,
        f1:this.vFormFac.value.fruta1,
        f2:this.vFormFac.value.fruta2,
        f3:0,
        lc:LecheCond};
        desc = this.getRaspadoName(this.vFormFac.value.tamanio);
        desc += ' J(' + this.getJarabeName(this.vFormFac.value.jarabe1);
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta2) + ')';
        desc += ' F(' + this.getFrutaName(this.vFormFac.value.fruta1);        
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta2) + ')'
        desc += ' ' +strLechCon;
      break;

      case 114:
        arr2 = {j1:this.vFormFac.value.jarabe1,
        j2:this.vFormFac.value.jarabe2,
        j3:this.vFormFac.value.jarabe3,
        f1:this.vFormFac.value.fruta1,
        f2:this.vFormFac.value.fruta2,
        f3:this.vFormFac.value.fruta3,
        lc:LecheCond};

        desc = this.getRaspadoName(this.vFormFac.value.tamanio);
        desc += ' J(' + this.getJarabeName(this.vFormFac.value.jarabe1);
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta2);
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta3) + ')';
        desc += ' F(' + this.getFrutaName(this.vFormFac.value.fruta1);        
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta2);  
        desc += '/' + this.getFrutaName(this.vFormFac.value.fruta3) + ')';
        desc += ' ' +strLechCon;
      break;
    }
    //Ingredientes del Raspado para control de inventario
 

    temp = {id_item:this.vFormFac.value.tamanio,
            desc_item:desc,
            cant:this.vFormFac.value.cant,
            price:this.vFormFac.value.price,
            isv:0, 
            arrInv:arr2,
            numReg:vRegN};

    
    this.dtable.push(temp);
    this.datosFactura = new MatTableDataSource(this.dtable);

    //adicionales 
    if(Number(this.vFormFac.value.tamanio)==112 || Number(this.vFormFac.value.tamanio)==113
      || Number(this.vFormFac.value.tamanio)==114)
    {
      if(this.validaCampo(this.vFormFac.value.extraFruta)){
        let idsExtra = this.vFormFac.value.extraFruta.split('-')
        //console.log(this.vFormFac.value.extraFruta);
        temp = {id_item:idsExtra[0],
          desc_item:'Extra Fruta (' + this.getFrutaName(idsExtra[1]) +')',
          cant:1,
          price:this.getPrecioExtras(idsExtra[0]),
          isv:0, 
          arrInv:{f1:idsExtra[1], f2:"0", f3:"0", j1:"0", j2:"0", j3:"0", lc:"N"},
          numReg:vRegN
        };

      this.dtable.push(temp);
      this.datosFactura = new MatTableDataSource(this.dtable);
      }               
    }
    if(this.vFormFac.value.extraLecheCon){
      let precioLech = 0;
      let idLeche = "121";
      if(Number(this.vFormFac.value.tamanio)==113 || Number(this.vFormFac.value.tamanio)==114)
      {
        precioLech = 7.00;
        idLeche = "122";
      }else{
        precioLech = 5.00;
        idLeche = "121";
      }
      temp = {id_item:idLeche,
        desc_item:'Extra Leche Condezada',
        cant:1,
        price:precioLech,
        isv:0, 
        arrInv:{f1:"0", f2:"0", f3:"0", j1:"0", j2:"0", j3:"0", lc:"S"},
        numReg:vRegN
      };

      this.dtable.push(temp);
      this.datosFactura = new MatTableDataSource(this.dtable);
    }
    this.calculaTotales();
    this.limpiItems();

  }

  setPrice(idSize :any){
    for(let xVal of this.vSizes){
      if(xVal.id==Number(idSize)){        
        this.vFormFac.patchValue({price:xVal.price});
        return;
      }
    }
  }

  calculaTotales(){
    this.dtosTotales = {vndor:this.vVendedor, total:0, efectivo:0, tarjeta:0, subTotExento:0, subTotGrabado:0, subTotExonerado:0, descuento:0, impuesto15:0, impuesto18:0};
    for(let x of this.dtable){
      this.dtosTotales.subTotExento += (x.price*x.cant);
    }
    this.dtosTotales.total=this.dtosTotales.subTotExento;
    this.dtosTotales.efectivo = this.dtosTotales.total;
  }

  facturar(){
    if(this.dtosTotales.total>0){      
      //console.log('Facturando..');
      //console.log(this.dtable);
      //console.log(this.dtosTotales);

      this.app_svr.saveFact({op:201, data:this.dtable, vtotales:this.dtosTotales}).subscribe(result=>{
        let x = JSON.stringify(result);
        let vRes = JSON.parse(x);
        //console.log(vRes);
        if(vRes.result==100 && vRes.datos.msj=='ok'){      
          console.log('Fact Saved');
          //window.open('http://amgdevs.com/views/printfact.php?vF=' + vRes.datos.idfac , '', 'width=500, height=650');    
          this.limpiarFact();
          alert('Factura Guardada Exitosamente');
        }else{
          console.log('Error SErver');
        }
      },
      error=>{
        console.log('Error de conexion' + error);
      });
    }
  }

  limpiarFact(){
    this.dtable = [];
    this.datosFactura = new MatTableDataSource();
    this.dtosTotales = {vndor:this.vVendedor, total:0, efectivo:0, tarjeta:0, subTotExento:0, subTotGrabado:0, subTotExonerado:0, descuento:0, impuesto15:0, impuesto18:0};
    this.limpiItems();
  }

  selected(obj:any){
    this.lecheC= true;
    switch(Number(obj.value)){
      case 110:
        this.flag_jarabe1 = true;
        this.flag_jarabe2 = false;
        this.flag_jarabe3 = false;
        this.flag_fruta1 = false;
        this.flag_fruta2 = false;
        this.flag_fruta3 = false;
        this.extraF = false;
        this.extralecheC = true;

        this.vFormFac = this.formBuildr.group({
          tamanio:[obj.value,[Validators.required]],
          price:['',[]],
          jarabe1:['',[Validators.required]],
          jarabe2:['',[]],
          jarabe3:['',[]],      
          fruta1:['',[]],
          fruta2:['',[]],
          fruta3:['',[]],
          cant:[1, [Validators.required]],
          lechCon:[true, []],      
          extraFruta:['', []],    
          extraLecheCon:['', []]         
        });
      break;
      case 111:
        this.flag_jarabe1 = true;
        this.flag_jarabe2 = false;
        this.flag_jarabe3 = false;
        this.flag_fruta1 = true;
        this.flag_fruta2 = false;
        this.flag_fruta3 = false;
        this.extralecheC = true;
        this.extraF = false;

        this.vFormFac = this.formBuildr.group({
          tamanio:[obj.value,[Validators.required]],
          price:['',[]],
          jarabe1:['',[Validators.required]],
          jarabe2:['',[]],
          jarabe3:['',[]],      
          fruta1:['',[Validators.required]],
          fruta2:['',[]],
          fruta3:['',[]],
          cant:[1, [Validators.required]],
          lechCon:[true, []],      
          extraFruta:['', []],    
          extraLecheCon:['', []]         
        });
      break;
      case 112:
        this.flag_jarabe1 = true;
        this.flag_jarabe2 = true;
        this.flag_jarabe3 = false;
        this.flag_fruta1 = true;
        this.flag_fruta2 = true;
        this.flag_fruta3 = false;
        this.extralecheC = true;
        this.extraF = true;

        this.vFormFac = this.formBuildr.group({
          tamanio:[obj.value,[Validators.required]],
          price:['',[]],
          jarabe1:['',[Validators.required]],
          jarabe2:['',[Validators.required]],
          jarabe3:['',[]],      
          fruta1:['',[Validators.required]],
          fruta2:['',[Validators.required]],
          fruta3:['',[]],
          cant:[1, [Validators.required]],
          lechCon:[true, []],      
          extraFruta:['', []],    
          extraLecheCon:['', []]         
        });
      break;
      case 113:
        this.flag_jarabe1 = true;
        this.flag_jarabe2 = true;
        this.flag_jarabe3 = false;
        this.flag_fruta1 = true;
        this.flag_fruta2 = true;
        this.flag_fruta3 = false;
        this.extralecheC = true;
        this.extraF = true;

        this.vFormFac = this.formBuildr.group({
          tamanio:[obj.value,[Validators.required]],
          price:['',[]],
          jarabe1:['',[Validators.required]],
          jarabe2:['',[Validators.required]],
          jarabe3:['',[]],      
          fruta1:['',[Validators.required]],
          fruta2:['',[Validators.required]],
          fruta3:['',[]],
          cant:[1, [Validators.required]],
          lechCon:[true, []],      
          extraFruta:['', []],    
          extraLecheCon:['', []]         
        });
      break;
      case 114:
        this.flag_jarabe1 = true;
        this.flag_jarabe2 = true;
        this.flag_jarabe3 = true;
        this.flag_fruta1 = true;
        this.flag_fruta2 = true;
        this.flag_fruta3 = true;
        this.extralecheC = true;
        this.extraF = true;

        this.vFormFac = this.formBuildr.group({
          tamanio:[obj.value,[Validators.required]],
          price:['',[]],
          jarabe1:['',[Validators.required]],
          jarabe2:['',[Validators.required]],
          jarabe3:['',[Validators.required]],     
          fruta1:['',[Validators.required]],
          fruta2:['',[Validators.required]],
          fruta3:['',[Validators.required]],
          cant:[1, [Validators.required]],
          lechCon:[true, []],      
          extraFruta:['', []],    
          extraLecheCon:['', []]         
        });
      break;
    }
    
    this.setPrice(Number(obj.value));
  }


  getJarabeName(idJarabe:any):string{
    let result='';
    for(let xVal of this.vJarabes){
      if(xVal.id==Number(idJarabe)){  
        //console.log(xVal.name);      
        result = xVal.name;
        return result;
      }
    }
    return result;
  }

  getFrutaName(idFruta:any):string{
    let result='';
    for(let xVal of this.vFrutas){
      if(xVal.id==Number(idFruta)){        
        result = xVal.name;
        return result;
      }
    }
    return result;
  }

  getRaspadoName(idRaspado:any):string{
    let result='';
    for(let xVal of this.vSizes){
      if(xVal.id==Number(idRaspado)){        
        result = xVal.name;
        return result;
      }
    }
    return result;
  }

  getPrecioExtras(idExtra:any):number{
    let result = 0;
    for(let xVal of this.vExtras){
      if(xVal.id==Number(idExtra)){        
        result = xVal.price;
        return result;
      }
    }
    return result;
  }

  validaCampo(vStr:any){
    let res = true;
    if(/^\s*$/.test(vStr)){
      res = false;
    }
    return res;
  }

  printFac(idFac:any){
    console.log(idFac);
    window.open('http://amgdevs.com/views/printfact.php?vF=' + idFac , '', 'width=500, height=650');    
  }

  showFacs(vFlag:any){
    let strFech = '';
    if(vFlag==1){      
      strFech = this.getFech(this.fech_facs);
    }else{
      strFech = String(this.fech_facs);
    }

    this.tblFacsPrint = new MatTableDataSource(this.vFacsPrint);
    this.app_svr.getFacturasPrint({op:103, fech:strFech}).subscribe(result=>{
      let x = JSON.stringify(result);
      let vRes = JSON.parse(x);
      //console.log(vRes);
      this.tblFacsPrint = new MatTableDataSource(vRes.datos);
    });
  }

  getFech(vfech:Date){
    let fechFinal = vfech.getFullYear() + '-';
    if((vfech.getMonth()+1)<10){
      fechFinal += '0' + (vfech.getMonth()+1);
    }else{
      fechFinal += (vfech.getMonth()+1);
    }
    if(vfech.getDate()<10){
      fechFinal += '-0' + vfech.getDate();
    }else{
      fechFinal += '-' + vfech.getDate();
    }
    return fechFinal;
  }

  removeItem(regItm:number){
    //console.log(regItm);
    for(let i=0;i<this.dtable.length;i++){
      if(this.dtable[i].numReg==regItm){
        this.dtable.splice(i,1);
      }
    }    
    this.datosFactura = new MatTableDataSource(this.dtable);
    this.calculaTotales();    
    this.limpiItems();
  }
}
