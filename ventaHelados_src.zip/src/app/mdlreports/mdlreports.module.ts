
import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { ConfiguserComponent } from '../mdlreports/configuser/configuser.component';
import { MdlsharedModule } from '../mdlshared/mdlshared.module';
import { RptsalesComponent } from './rptsales/rptsales.component';
import { HighchartsChartModule} from 'highcharts-angular';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { DashVtas01Component } from './dash-vtas01/dash-vtas01.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    ConfiguserComponent,
    RptsalesComponent,
    DashVtas01Component
  ],
  imports: [
    MdlsharedModule,
    CommonModule,
    HighchartsChartModule,
    MatButtonModule,
    MatSelectModule,
    FormsModule
  ]

})
export class MdlreportsModule { }
