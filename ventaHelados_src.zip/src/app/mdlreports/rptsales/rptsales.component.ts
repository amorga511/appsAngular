import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { FilesaveService } from 'src/app/filesave.service';
import { WsappService } from 'src/app/wsapp.service';

@Component({
  selector: 'app-rptsales',
  templateUrl: './rptsales.component.html',
  styleUrls: ['./rptsales.component.css']
})
export class RptsalesComponent implements OnInit {

  constructor(private svr_app:WsappService, private exportFile:FilesaveService) { }

  aniomesRpt:any;
  highcharts = Highcharts;
  vArrDatos = [10,23,34,34,23,12,56,78];
  cbAnios = [{id:"0", name:"2021-jun"}];
  monthsName = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  tblReports = [{reportName:"Facturacion Mensual"}];
  rptFacs = [];

  chartOptions: Highcharts.Options = {
    title: {
      text: "Infosys stock value"
    },
    xAxis: {
      categories: ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    },
    yAxis: {
      title: {
        text: "Infosys Stock value in dollar"
      }
    },
    series: [{
      data: this.vArrDatos,
      type: 'line'
    }]
  }

  ngOnInit(): void {
    this.cbAnios = [];
    let date = new Date();    
    let id='';
    let name='';
    let firstDate = "0";
    for(let x=0; x<12; x++){  
      id='';
      name='';
      date = new Date();  
      date.setDate(date.getDate()-(x*30));
      if(date.getMonth()+1<10){
        id = date.getFullYear()+'0'+ (date.getMonth()+1);
      }else{        
        id = date.getFullYear()+''+ (date.getMonth()+1);
      }
      name = date.getFullYear() + '-' + this.monthsName[date.getMonth()];
      this.cbAnios.push({id:id, name:name});
      if(firstDate=="0"){
        firstDate = id;
      }
    }
    this.aniomesRpt = firstDate;
  }

  downloadRpt(varx:any){
    console.log(varx);

    console.log(this.aniomesRpt);
    this.svr_app.getFactuasDet({op:104, aniomes:this.aniomesRpt}).subscribe(result=>{
      let x = JSON.stringify(result);
      let vRes = JSON.parse(x);
      if(vRes.datos.length>0){
        console.log(vRes);  
        this.rptFacs=vRes.datos; 
        this.exportFile.downloadFile(this.rptFacs, ["codprod",
                                                      "det",
                                                      "fech",
                                                      "frt1",
                                                      "frt2",
                                                      "frt3",
                                                      "idfac",
                                                      "jrb1",
                                                      "jrb2",
                                                      "jrb3",
                                                      "leche_con",
                                                      "precio",
                                                      "produc",
                                                      "total",
                                                      "unidades"], 'reporteFacturacion');

      }else{
        alert('No hay datos para la fecha seleccionada');
      }
     
    });
    
  }

}
