import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RptsalesComponent } from './rptsales.component';

describe('RptsalesComponent', () => {
  let component: RptsalesComponent;
  let fixture: ComponentFixture<RptsalesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RptsalesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RptsalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
