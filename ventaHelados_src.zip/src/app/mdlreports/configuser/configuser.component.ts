import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configuser',
  templateUrl: './configuser.component.html',
  styleUrls: ['./configuser.component.css']
})
 

export class ConfiguserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
