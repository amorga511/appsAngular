import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-vtas01',
  templateUrl: './dash-vtas01.component.html',
  styleUrls: ['./dash-vtas01.component.css']
})
export class DashVtas01Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
