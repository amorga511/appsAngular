import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashVtas01Component } from './dash-vtas01.component';

describe('DashVtas01Component', () => {
  let component: DashVtas01Component;
  let fixture: ComponentFixture<DashVtas01Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashVtas01Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashVtas01Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
