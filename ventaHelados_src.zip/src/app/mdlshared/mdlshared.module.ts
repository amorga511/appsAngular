import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeadComponent } from './head/head.component';

import { MatSidenavModule } from '@angular/material/sidenav';
import { AppRoutingModule } from '../app-routing.module';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule} from  '@angular/material/button';
import { DialogMenuComponent } from './dialog-menu/dialog-menu.component';
import { MatInputModule } from '@angular/material/input';




@NgModule({
  declarations: [
    HeadComponent,
    DialogMenuComponent
  ],
  imports: [
    CommonModule,
    MatSidenavModule,
    AppRoutingModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule
  ],
  exports:[
    HeadComponent,
    DialogMenuComponent
  ]
})
export class MdlsharedModule { }
