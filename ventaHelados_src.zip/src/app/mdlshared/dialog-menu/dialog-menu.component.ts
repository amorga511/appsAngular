import { Component, OnInit } from '@angular/core';
import { MatDialogClose, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog-menu',
  templateUrl: './dialog-menu.component.html',
  styleUrls: ['./dialog-menu.component.css']
})
export class DialogMenuComponent implements OnInit {

  constructor(public dialogItem: MatDialogRef<DialogMenuComponent>) { }

  vArrMenuItems = [{id:110, title:"Tradicional", price:20, desc:"Tradicional", img:""},
  {id:111, title:"1 Fruta 8oz", price:25, desc:"1Fruta vaso de 8oz", img:""},
  {id:112, title:"2 Frutas 10oz", price:30, desc:"desc breve", img:""},
  {id:113, title:"2 Frutas 45oz", price:45, desc:"desc breve", img:""},
  {id:114, title:"3 Frutas 32oz", price:55, desc:"desc breve", img:""}];

  result_json = {id:'', title:'', price:0, desc:'', cant:0};
  ngOnInit(): void {
  }

  itemSelected(idItem:any){
    let item_Result;
    let x;
    if(idItem)
    {
      switch(idItem){
        case 110:
          x = (<HTMLInputElement>document.getElementById("110")).value;
          this.result_json.id=idItem;
          this.result_json.title=this.vArrMenuItems[0].title;
          this.result_json.price=this.vArrMenuItems[0].price;        
          this.result_json.title=this.vArrMenuItems[0].title;
          this.result_json.cant =  Number(x);
        break;
        case 111:
          x = (<HTMLInputElement>document.getElementById("111")).value;
          this.result_json.id=idItem;
          this.result_json.title=this.vArrMenuItems[1].title;
          this.result_json.price=this.vArrMenuItems[2].price;        
          this.result_json.title=this.vArrMenuItems[1].title;
          this.result_json.cant =  Number(x);
        break;
        case 112:
          x = (<HTMLInputElement>document.getElementById("112")).value;
          this.result_json.id=idItem;
          this.result_json.title=this.vArrMenuItems[2].title;
          this.result_json.price=this.vArrMenuItems[2].price;        
          this.result_json.title=this.vArrMenuItems[2].title;
          this.result_json.cant =  Number(x);
        break;
        case 113:
          x = (<HTMLInputElement>document.getElementById("113")).value;
          this.result_json.id=idItem;
          this.result_json.title=this.vArrMenuItems[3].title;
          this.result_json.price=this.vArrMenuItems[3].price;        
          this.result_json.title=this.vArrMenuItems[3].title;
          this.result_json.cant =  Number(x);
        break;
        case 114:
          x = (<HTMLInputElement>document.getElementById("114")).value;
          this.result_json.id=idItem;
          this.result_json.title=this.vArrMenuItems[4].title;
          this.result_json.price=this.vArrMenuItems[4].price;        
          this.result_json.title=this.vArrMenuItems[4].title;
          this.result_json.cant =  Number(x);
        break;
      }
    }
    this.dialogItem.close(this.result_json);
  }
}
