import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WsappService {

  constructor(private http: HttpClient) {
  }
  
  url:string = 'http://wsraspados.amgdevs.com/ws_raspados.php'; 

  public validaLogin(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

  public saveFact(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

  public getProducts(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

  public getFrutasJarabes(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

  public getFacturasPrint(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

  //for reports
  public getFactuasDet(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

}
