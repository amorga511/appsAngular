import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MainComponent } from './main/main.component';
import { GuardAppGuard } from './guard-app.guard';
import { ConfiguserComponent } from './mdlreports/configuser/configuser.component';
import { FacturacionComponent } from './mdlventas/facturacion/facturacion.component';
import { RptsalesComponent } from './mdlreports/rptsales/rptsales.component';
import { DashVtas01Component } from './mdlreports/dash-vtas01/dash-vtas01.component';

const routes: Routes = [  
  
  {path:'login', component:LoginComponent, pathMatch:'full'},  
  {path:'facturacion', component:FacturacionComponent, pathMatch:'full', canActivate:[GuardAppGuard]},
  {path:'main', component:MainComponent, pathMatch:'full', canActivate:[GuardAppGuard]}, 
  {path:'confuser', component:ConfiguserComponent, pathMatch:'full', canActivate:[GuardAppGuard]},  
  {path:'rptsales', component:RptsalesComponent, pathMatch:'full', canActivate:[GuardAppGuard]},  
  {path:'dashVtas01', component:DashVtas01Component, pathMatch:'full', canActivate:[GuardAppGuard]},  
  {path:'**', redirectTo:'/main'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
