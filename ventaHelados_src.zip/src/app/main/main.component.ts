import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor(private cookieS: CookieService, private router:Router) { }

  v_arr_menu = [{id:101, name:'Ventas', img:'assets/sells.png'},
                {id:102, name:'Caja', img:'assets/cashier.png'},
                {id:103, name:'Compras', img:'assets/buys.png'}];
  v_arr_menu2 = [{id:201, name:'Reportes de Ventas', img:'assets/cashier.png'},{id:202, name:'Mov Caja'},{id:203, name:'Fluno Efectivo'}];

  vprecio='';

  ngOnInit(): void {
    this.v_arr_menu2 = [{id:201, name:'Reporteria', img:'assets/reports.png'},
                        {id:301, name:'Tablero de Ventas', img:'assets/dashimg.png'}];
    //console.log(this.cookieS.get('login'));
  }

  menuSwitch(mId:number){
    //console.log(mId);
    switch(mId){
      case 101:
        this.router.navigate(['/facturacion']);
      break;
      case 201:
        this.router.navigate(['/rptsales']);
      break;
      case 301:
        this.router.navigate(['/dashVtas01']);
      break;
      default:
        this.router.navigate(['/main']);
      break;
    }
  }

}
