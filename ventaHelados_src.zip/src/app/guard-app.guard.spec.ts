import { TestBed } from '@angular/core/testing';

import { GuardAppGuard } from './guard-app.guard';

describe('GuardAppGuard', () => {
  let guard: GuardAppGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(GuardAppGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
