import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GuardAppGuard implements CanActivate {

  constructor(private cookieS:CookieService, private router_app: Router){ }

  protected valida_permisos(pagName:string){
    if(this.cookieS.check('login')){
      console.log(pagName);
      return true;
    }else{      
      this.router_app.navigate(['/login']);
      console.log('LoginFalse');
      return false;
    };
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    //console.log(route.url[0].path);
    return this.valida_permisos(route.url[0].path);
  }
  
}
