import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { WsappService } from '../wsapp.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router_app: Router, private cookieS:CookieService, private app_srvs:WsappService) { }

  txtUser='';
  txtPwd=''
  txtMsj='';


  ngOnInit(): void {
    if(this.cookieS.check('login')){
      this.router_app.navigate(['/main']);
    }
  }

  public login(){
    //console.log('Login..' + this.txtUser + '-' + this.txtPwd);
    
    if(this.txtUser.trim()!='' && this.txtPwd.trim()!='')
    {
      
      this.txtMsj='';
      this.app_srvs.validaLogin({op:100, usr:this.txtUser, pwd:this.txtPwd}).subscribe(result=>{
        let x = JSON.stringify(result);
        let vRes = JSON.parse(x);
        //console.log(vRes);
        if(vRes.result==100 && vRes.datos.msj=='ok'){        
          this.cookieS.set('login', 'true');    
          this.cookieS.set('pdv', vRes.datos.pdv);    
          this.cookieS.set('usr', vRes.datos.usr);    
          this.cookieS.set('name', vRes.datos.name); 
          this.cookieS.set('prof', vRes.datos.prof);
          this.router_app.navigate(['/main']);
        }else{
          console.log('Usuario o Clave Incorrecta..');
          this.txtMsj='Usuario o Clave Incorrecta.!!';
        }
      },
      error=>{
        console.log(error );        
        this.txtMsj='Error Consultando el Servidor';
      });
    }
  }

}
