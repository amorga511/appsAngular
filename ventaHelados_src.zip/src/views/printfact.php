﻿<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title></title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-store" />

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<?php

    /*if(isset($_SESSION["login"])){
        if($_SESSION["login"]==0){
            header("Location: ../../index.php");
        }
    }else{
        header("Location: ../../index.php");
    }*/

    if(false){
        $x=null;
    }else{
        $numFac = $_GET["vF"];

        $vItems = array();
        $vCantLetras = "0/100";

        $cai="";

        $rtn = "";
        $empresa = "";
        $eDir = "";
        $eTel = "";
        $eEmail = "";



        $vCliente = "";
        $vTel = "";
        $vRTN ="";
        $vCaja ="0";
        $vCajero = "";
        $vCajeroName = "NA";
        $vFecha = "";
        $vVendedor = "";
        $vVendedorName = "NA";

        $vTotal = 0;
        $vSubTotalE = 0;
        $vSubTotalG = 0;
        $vDesc = 0;
        $vISV = 0;
        $vEfectivo = 0;
        $vTarjeta = 0;

        
        $facDesd="";
        $facHasta="";
        $fechLimite ="";

        include 'db_conection.php';

        $vQuery = "SELECT * FROM tbl_facturas where id='" .  $numFac . "'";
      
        if($res1 = $conn->query($vQuery)){
            $rows = $res1->fetch(PDO::FETCH_ASSOC);
            $cai = $rows["cai"];

            $vFecha = $rows["fech_fac"];
            $vCliente = $rows["client"];
            $vTel = $rows["tel_client"];
            $vRTN = $rows["rtn_client"];
            $vVendedor = $rows["salesman"];
            $vCajero = $rows["cajero"];
            $vCaja = $rows["caja"];


            $vSubTotalE = $rows["subtot_exemp"];
            $vSubTotalG = $rows["subtot_taxable"];
            $vDesc = $rows["descounts"];
            $vISV = $rows["isv15"];
            $vTotal = $rows["total"];

            $vEfectivo = $rows["efectivo"];
            $vTarjeta = $rows["tarjeta"];
            $vStatusFac = $rows["estado"];
            $strAnulada = "<div style=\"width:98%; border:solid 2px black\"><b>FACTURA ANULADA</b></div><br/>";
            $vAnlMotiv = "";
            
        }
        
        $vQuery = "SELECT * FROM tbl_factura_detalle where factura_id='" . $numFac . "'";
        if($res2 = $conn->query($vQuery)){
            while($row2 = $res2->fetch(PDO::FETCH_ASSOC)){
                $sTot = (float)$row2["unidades"] * $row2["precio"];
                array_push($vItems, array("cod"=>$row2["cod_item"],"desc"=>$row2["detalle"], "und"=>$row2["unidades"],"price"=>$row2["precio"], "stot"=>$sTot));
            }
        }

        $vSQL = "SELECT * FROM tbl_cai_control where cai='" . $cai . "'";
        if($resC = $conn->query($vSQL)){
            while($rowC = $resC->fetch(PDO::FETCH_ASSOC)){
                $facDesd = $rowC["rango_desde"];
                $facHasta = $rowC["rango_hasta"];
                $fechLimite = $rowC["fecha_limite"];
            }
        }


        $vSQL = "SELECT * FROM tbl_app_empresa";
        if($resC = $conn->query($vSQL)){
            while($rowC = $resC->fetch(PDO::FETCH_ASSOC)){
                $rtn = $rowC["rtn"];
                $empresa = $rowC["bsns_name"];
                $eDir = $rowC["bsns_dir"];
                $eTel = $rowC["bsns_tel"];
                $eEmail = $rowC["email"];
            }
        }
/*
 

        if($vStatusFac == 2){
            $vSQL = "SELECT motivo_anl FROM tbl_anl_motivo where id_fac='" . $numFac . "'";
            if($resC = $con->query($vSQL)){
                while($rowC = $resC->fetch_array()){
                    $vAnlMotiv = $rowC[0];
                }
            }

            $strAnulada = "<div style=\"width:98%; border:solid 2px black\"><b>FACTURA ANULADA</b>";
            $strAnulada .= "<br />" . $vAnlMotiv . "</div><br/>";
        }*/
        
    }
?>

<style>
#dvBody{
    width:280px;
    /*background-color: gary;*/
}
.font1{
    font-family: 'cambria';
    font-size:16px;
    line-height: 1.3;
    padding-left: 2px;
    padding-right: 2px;
}

.font2{
    line-height: 1.3;
    font-family: 'cambria';
    font-size: 14px;
    padding-left: 2px;
    padding-right: 2px;
}

.font3{
    line-height: 1.3;
    font-family: 'cambria';
    font-size: 12px;
    text-align: middle;    
    padding: 2px;
    /*border:solid 1px;*/
}


}
</style>
</head>
<body>
<div id="dvBody">
<center>
    <br />
    <img src="applogo.jpeg" width="200px" height="130px" style="margin-bottom:10px" /><br>
    <b><div class="font1"><?= $empresa; ?></div></b>
    <div class="font2" >RTN: <?= $rtn; ?></div>
    <div class="font2"><?= $eDir; ?></div>
    <div class="font2">Tel: <?= $eTel; ?></div>
    <div class="font2">E-mail: <?= $eEmail; ?></div>
    <div class="font2" style="margin-top:5px">CAI</div>
    <div class="font2"><?= $cai; ?></div>
   
    <div class="font2">Desde <?= $facDesd; ?></div>
    <div class="font2">Hasta <?= $facHasta; ?></div>
    <div class="font2">Fecha Limite Emisión</div>
    <div class="font2"><?= $fechLimite; ?></div>
    <br>
<?php
    if($vStatusFac == 2){
        echo $strAnulada;
    }
?>   
    <div class="font1"><b>Factura #</b></div>
    <div class="font1"><b><?= $numFac ?></b></div>
    <div class="font1">Fecha: <?= $vFecha ?></div>
    <div class="font1">Caja: <?= $vCaja ?></div>
    <div class="font1">Cajero: <?= $vCajeroName ?></div>
    <div class="font1">Vendedor: <?= $vVendedorName ?></div>

    <div class="font1" style="text-align: left; margin-top:10px">Cliente: <?= $vCliente ?></div>
    <div class="font1" style="text-align: left">Telefono: <?= $vTel ?></div>
    <div class="font1" style="text-align: left">RTN: <?= $vRTN ?></div>

    <div class="font1" style="text-align: left; margin-top:10px">N° Ord. Compra exenta: <?= null ?></div>    
    <div class="font1" style="text-align: left">N° registro exonerado: <?= null ?></div>    
    <div class="font1" style="text-align: left">N° registro de la SAG: <?= null ?></div>

    <div class="font1" style="border-bottom: solid 1px gray; margin: 0px">-</div>
    <div class="row" style="margin: 0px; padding-bottom:2px; border-bottom: solid 1px gray;">
        <!--<div class="col-xs-2 font2">Cod.</div>-->
        <div class="font2" style="width:100%">Descript</div>
        <div class="row">
            <div class="font2" style="width:33%">Unds.</div>
            <div class="font2" style="width:33%">Precio</div>
            <div class="font2" style="width:34%">S.Total</div>
        </div>
    </div>
<?php
    for($i=0;$i<count($vItems); $i++){
    echo "<div class=\"row\" style=\"margin: 5px;\">
        <div class=\"font2\" style=\"text-align:left; width:100%\">". $vItems[$i]["desc"] ."</div></div>
        <div class=\"row\" style=\"margin-right:3px; margin-top:-3px\">
        <div class=\"font2\" style=\"width:33%\">". $vItems[$i]["und"] ."</div>
        <div class=\"font2\" style=\"width:33%\">L.". $vItems[$i]["price"] ."</div>
        <div class=\"font2\" style=\"text-align:right; width:34%\"><span\">L.". $vItems[$i]["stot"] ."</span></div>
        </div>";
    
    /*echo "<div class=\"row\" style=\"margin: 0px;\">
        <div class=\"col-xs-2 font3\">". $vItems[$i]["cod"] ."</div>
        <div class=\"col-xs-4 font3\">". $vItems[$i]["desc"] ."</div>
        <div class=\"col-xs-2 font3\">". $vItems[$i]["und"] ."</div>
        <div class=\"col-xs-2 font3\">". $vItems[$i]["price"] ."</div>
        <div class=\"col-xs-2 font3\" style=\"text-align:right;\"><span\">". $vItems[$i]["stot"] ."</span></div>
        </div>";*/
    }
?>
    <div class="row font1" style="margin: 0px; margin-top:7px; padding-top: 5px; border-top: solid 1px gray; text-align: right;">
        <div style="width:80%">S. Tot. Exonerado L.</div>
        <div style="padding-right:2px; width:20%">0.00</div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="width:80%">S. Tot. Exento L.</div>
        <div style="padding-right:2px; width:20%"><?= $vSubTotalE ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="width:80%">S. Tot. 15.00% L.</div>
        <div style="padding-right:2px; width:20%"><?= $vSubTotalG ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="width:80%">S. Tot. 18.00% L.</div>
        <div style="padding-right:2px; width:20%">0.00</div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="width:80%">Desc. y rebajas L.</div>
        <div style="padding-right:2px; width:20%"><?= $vDesc ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="width:80%">Impuesto 15.00% L.</div>
        <div style="padding-right:2px; width:20%"><?= $vISV ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="width:80%">Impuesto 18.00% L.</div>
        <div style="padding-right:2px; width:20%">0.00</div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="padding-top:5px; width:80%"><b>TOTAL L.</b></div>
        <div style="border-top: solid 1px gray; padding-right:2px; padding-top:5px; width:20%"><b><?= $vTotal ?></b></div>
    </div>

    <div class="row font1" style="margin: 0px; text-align: right; margin-top: 8px">
        <div style="padding-top:0px; width:80%"><b>EFECTIVO L.</b></div>
        <div style="padding-right:2px; width:20%"><b><?= $vEfectivo ?></b></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div style="width:80%"><b>TARJETA L.</b></div>
        <div style="padding-right:2px; width:20%"><b><?= $vTarjeta ?></b></div>
    </div>

    <div class="font2" id="cantLtr" style="text-align: left; margin-top:10px; margin-bottom:10px;"><?= $vCantLetras; ?></div>
    <div class="font1" style="text-align: left;">*******************************************</div>
    <div class="font1"><b>!! Gracias por su Compra !!</b></div>
    <br />
    <br />-
</center>
</div>
</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="js_numTostr.js"></script>
<script type="text/javascript">
    
    $("#cantLtr").html(str_number(<?= $vTotal; ?>));
   window.print();
</script>

</html>
