import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bailarines',
  templateUrl: './bailarines.component.html',
  styleUrls: ['./bailarines.component.css']
})
export class BailarinesComponent implements OnInit {

  constructor() { }

  bailarines=[{nombre:"AMG", grupo:"xyz"},
              {nombre:"MAM", grupo:"xyz"},
              {nombre:"AGM", grupo:"xyz"},{nombre:"AGM", grupo:"xyz"},{nombre:"AGM", grupo:"xyz"},
              {nombre:"AGM", grupo:"xyz"},{nombre:"AGM", grupo:"xyz"},{nombre:"AGM", grupo:"xyz"}];
  ngOnInit(): void {
  }

}
