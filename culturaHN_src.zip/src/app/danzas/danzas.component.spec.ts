import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DanzasComponent } from './danzas.component';

describe('DanzasComponent', () => {
  let component: DanzasComponent;
  let fixture: ComponentFixture<DanzasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DanzasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DanzasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
