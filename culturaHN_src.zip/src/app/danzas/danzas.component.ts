import { AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import {MatSort} from '@angular/material/sort';
import { WsappService } from '../wsapp.service';
import { CmpDanzaComponent } from '../cmp-danza/cmp-danza.component';


export interface topdanzas {
  puesto:number,
  nombre:string,
  puntuacion:number,
  grupo:string,
  video:string
}

@Component({
  selector: 'app-danzas',
  templateUrl: './danzas.component.html',
  styleUrls: ['./danzas.component.css']
})



export class DanzasComponent implements OnInit, AfterViewInit {

  @ViewChild(MatSort)  sort!: MatSort;

  constructor(private appWS:WsappService) {     
  }

  lengArr = 0;
  vArrDanzas = [];
  dtable : topdanzas[]=[];

  listDate!:MatTableDataSource<any>;

  displayedColumns:string[] = ["puesto", "nombre", "puntuacion","grupo"];

  v_datos_app = {v_title:''};

  vFilterArr:any[]=[];

  
  ngOnInit() {   
    this.v_datos_app = {v_title:"Danzas"};
    this.listDate = new MatTableDataSource(this.dtable);

    this.appWS.getDanzas({op:101, id_danza:0})
    .subscribe(result => {
      let x = JSON.stringify(result);    
      let vRes = JSON.parse(x);
      //console.log(vRes);
      this.vArrDanzas = vRes.datos.vjson;
      //console.warn(this.vArrDanzas);
      this.vFilterArr = this.vArrDanzas.slice(0,10);
      this.lengArr = this.vArrDanzas.length;

    });

    this.appWS.getDanzas({op:101, id_danza:-1})
    .subscribe(result => {
      let x = JSON.stringify(result);
      let vRes = JSON.parse(x);
      let cont = 1;
      console.log(vRes);
      for(let val of vRes.datos.vjson){
        //console.log(val.nombre);
        let temp = {puesto:cont, nombre:val.nombre, puntuacion:val.puntuacion, grupo:val.grupo_video, video:val.url_video}

        cont++;
        this.dtable.push(temp);        
      }      
      this.listDate = new MatTableDataSource(this.dtable);
    });
    
  
 
  }

  ngAfterViewInit(){
    this.listDate.sort = this.sort;
  
  }

  onPageChange(data:any){
    this.vFilterArr = this.vArrDanzas.slice(data.pageIndex*data.pageSize,(data.pageIndex+1)*data.pageSize);
  }


}
