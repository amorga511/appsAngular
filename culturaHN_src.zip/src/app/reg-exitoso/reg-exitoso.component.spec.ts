import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegExitosoComponent } from './reg-exitoso.component';

describe('RegExitosoComponent', () => {
  let component: RegExitosoComponent;
  let fixture: ComponentFixture<RegExitosoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegExitosoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegExitosoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
