import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-exitoso',
  templateUrl: './reg-exitoso.component.html',
  styleUrls: ['./reg-exitoso.component.css']
})
export class RegExitosoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
