import { TestBed } from '@angular/core/testing';

import { GuardChnGuard } from './guard-chn.guard';

describe('GuardChnGuard', () => {
  let guard: GuardChnGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(GuardChnGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
