import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WsappService {

  constructor(private http: HttpClient ) {}
  url:string = 'https://iteshn.000webhostapp.com/ws_culturahn/ws_cultura.php';  
  //url:string = 'http://localhost/ws_culturahn/ws_cultura.php';

  headers = new HttpHeaders();

  public getDanzas(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

  public getUsers(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }

  public registerUser(datos:any){    
    return this.http.post(this.url, JSON.stringify(datos));
  }

  public validaLogin(datos:any){
    return this.http.post(this.url, JSON.stringify(datos));
  }
}
