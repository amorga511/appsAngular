import {Component, OnInit, AfterViewInit, Input } from '@angular/core';
import { WsappService } from '../wsapp.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})


export class HeaderComponent implements OnInit, AfterViewInit {

  @Input() v_datos_head={v_title:""};

  constructor(private wsApp: WsappService) {   
  }
  vTitleHead!:string;
  userName = 'USER NAME';
  flagReg:boolean = true;
  flagUsr:boolean = false;

  validaLogin():boolean
  {
 
    let data = {op:100, usr:'arodi.morga', pwd:'amg'};
    this.wsApp.validaLogin(data)
    .subscribe(vdata => {
      
    
    /*  let x = JSON.stringify(vdata);
    let vRes = JSON.parse(x);
    let vok = vRes.datos.msj;

        console.log(vRes);
        if(vRes.result==100 && vok=="ok"){               
          this.flagReg = false;
          this.flagUsr = true; 
        }else{
          this.flagReg = true;
          this.flagUsr = false; 
        }*/
      //console.log(vdata);
    },
    error => {alert(error.message); console.log(error); }
    );
    return true;
  }

  ngOnInit() {      
    this.vTitleHead = this.v_datos_head.v_title; 
    this.validaLogin();
  }

  ngAfterViewInit(){ 
  }
}
