import { TestBed } from '@angular/core/testing';

import { WsappService } from './wsapp.service';

describe('WsappService', () => {
  let service: WsappService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WsappService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
