import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpDanzaComponent } from './cmp-danza.component';

describe('CmpDanzaComponent', () => {
  let component: CmpDanzaComponent;
  let fixture: ComponentFixture<CmpDanzaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CmpDanzaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpDanzaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
