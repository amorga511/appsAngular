import { Component, OnInit, Input} from '@angular/core';
import { DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';


@Component({
  selector: 'app-cmp-danza',
  templateUrl: './cmp-danza.component.html',
  styleUrls: ['./cmp-danza.component.css']
})
export class CmpDanzaComponent implements OnInit {

  constructor(public sanitizer:DomSanitizer) { }
  @Input() arrDatos = {id:0, nombre:"", historia:"", recopiladores:"", grupo_video:"", tipo_danza:"", url_video:"", puntuacion:0};
  sourceVideo!:SafeResourceUrl;

  
  ngOnInit(){
      this.sourceVideo = this.sanitizer.bypassSecurityTrustResourceUrl(this.arrDatos.url_video);
  }

  ngAfterContentInit(){
    //console.warn(this.arrDatos);
  }

}
