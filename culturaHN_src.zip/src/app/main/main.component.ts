import { Component, OnInit } from '@angular/core';
import { AppModule } from '../app.module';
import { WsappService } from '../wsapp.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

  constructor(private WsappService:WsappService ) { }


  ngOnInit(): void {
        
    let back = document.getElementById("logDanza")
    if(back){
      //console.log(window.innerWidth);
      let vWith = window.innerWidth;
      if(vWith<1024){
        back.style.backgroundImage = 'url("/culturahn/assets/img/grupo02.JPG")';
      }else{        
        back.style.backgroundImage = 'url("/culturahn/assets/img/grupo01.JPG")';
      }      
      //back.style.backgroundColor = "gray";
    };
    //console.warn('Main Init');
  }
}
