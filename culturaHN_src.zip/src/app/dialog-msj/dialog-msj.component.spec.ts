import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogMsjComponent } from './dialog-msj.component';

describe('DialogMsjComponent', () => {
  let component: DialogMsjComponent;
  let fixture: ComponentFixture<DialogMsjComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DialogMsjComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogMsjComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
