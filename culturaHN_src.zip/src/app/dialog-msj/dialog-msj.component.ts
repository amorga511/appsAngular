import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog-msj',
  templateUrl: './dialog-msj.component.html',
  styleUrls: ['./dialog-msj.component.css']
})
export class DialogMsjComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<any>) { }

  ngOnInit(): void {
  }

  close(){
    this.dialogRef.close();
  }

}
