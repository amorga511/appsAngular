import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmp-bailarin',
  templateUrl: './cmp-bailarin.component.html',
  styleUrls: ['./cmp-bailarin.component.css']
})
export class CmpBailarinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
