import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmpBailarinComponent } from './cmp-bailarin.component';

describe('CmpBailarinComponent', () => {
  let component: CmpBailarinComponent;
  let fixture: ComponentFixture<CmpBailarinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CmpBailarinComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CmpBailarinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
