import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'
import { BailarinesComponent } from './bailarines/bailarines.component';
import { DanzasComponent } from './danzas/danzas.component';
import { GuardChnGuard } from './guard-chn.guard';
import { MainComponent } from './main/main.component';
import { ReglogComponent} from './reglog/reglog.component';

const routes: Routes = [
  {path:'main', component:MainComponent},  
  {path:'reglog', component:ReglogComponent},
  {path:'danzas', component:DanzasComponent, canActivate:[GuardChnGuard]},
  {path:'bailarines', component:BailarinesComponent},
  {path:'', redirectTo:'/main', pathMatch:'full'},
  {path:'**', redirectTo:'/main', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
