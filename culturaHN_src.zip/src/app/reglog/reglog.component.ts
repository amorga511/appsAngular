import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DialogMsjComponent } from '../dialog-msj/dialog-msj.component';
import { WsappService } from '../wsapp.service';


@Component({
  selector: 'app-reglog',
  templateUrl: './reglog.component.html',
  styleUrls: ['./reglog.component.css']
})

export class ReglogComponent implements OnInit {

  constructor(private ws_cultura:WsappService, private formBuilder:FormBuilder,
              public dialogReg: MatDialog) { }

  public formReg!: FormGroup;
  regFlag:boolean=true;

  vGrupos = [{id:101, name:"Raices Danlidences"},{id:99, name:"Otros"}];
  vDeptos = [{id:100, name:"Fco Morazan"},{id:101, name:"El Paraiso"}];

  ngOnInit(): void {
  
    let objA = document.getElementById("dvMenuBar_back");
    if(objA){      
      objA.className = "topBarBack";
    }

    this.formReg = this.formBuilder.group({
      nombre:['',[Validators.required]],
      apellido:['',[Validators.required]],
      bdate:['',[Validators.required]],
      tipouser:['',[Validators.required]],
      email:['',[Validators.required, Validators.email]],
      grupo:['',[Validators.required]],
      depto:['',[Validators.required]],
      ciudad:['',[Validators.required]],
      clave1:['',[Validators.required, Validators.minLength(6)]],
      clave2:['',[Validators.required, Validators.minLength(6)]]
    });
 
  }

  logIn(){
    this.dialogReg.open(DialogMsjComponent);
  }
  envioForm(){
      let vJsnDatos = {email:"", clave:"", nombre:"", apellido:"", bdate:"", tipouser:"",depto:"", muni:"",grupo:""};


      vJsnDatos.email = this.formReg.value.email;
      vJsnDatos.clave = this.formReg.value.clave1;
      vJsnDatos.nombre = this.formReg.value.nombre;
      vJsnDatos.apellido = this.formReg.value.apellido;
      vJsnDatos.bdate = this.formReg.value.bdate;
      vJsnDatos.tipouser = this.formReg.value.tipouser;
      vJsnDatos.depto = this.formReg.value.depto;
      vJsnDatos.muni = this.formReg.value.ciudad;
      vJsnDatos.grupo = this.formReg.value.grupo;

      console.log(vJsnDatos);
      
      let dtos_post = {op:201, data:vJsnDatos};      
      this.ws_cultura.registerUser(dtos_post).subscribe(vdata => {
      
        let x = JSON.stringify(vdata);
        let vRes = JSON.parse(x);
        let vok = vRes.datos.msj;
           console.log(vRes.datos);
            if(vRes.result==100 && vok=="ok"){  
              console.log('Usuario Registrado Exitosamente');
            }else{
              console.log(vRes.datos.msj); 
            }
        });
  }

}

