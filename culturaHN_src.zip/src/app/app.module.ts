import { NgModule } from '@angular/core';
import {LocationStrategy, HashLocationStrategy} from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import{ MatButtonModule} from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatIconModule} from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTabsModule} from '@angular/material/tabs';
import { MatInputModule} from '@angular/material/input';
import { HttpClientModule } from '@angular/common/http';
import { MatSelectModule} from '@angular/material/select';
import { MatPaginatorModule} from '@angular/material/paginator';
import { MatTableModule} from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatMenuModule } from  '@angular/material/menu';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { ReglogComponent } from './reglog/reglog.component';
import { HeaderComponent } from './header/header.component';
import { CmpDanzaComponent } from './cmp-danza/cmp-danza.component';
import { DanzasComponent } from './danzas/danzas.component';
import { BailarinesComponent } from './bailarines/bailarines.component';
import { CmpBailarinComponent } from './cmp-bailarin/cmp-bailarin.component';
import { DialogMsjComponent } from './dialog-msj/dialog-msj.component';
import { RegExitosoComponent } from './reg-exitoso/reg-exitoso.component';


@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    ReglogComponent,
    HeaderComponent,
    CmpDanzaComponent,
    DanzasComponent,
    BailarinesComponent,
    CmpBailarinComponent,
    DialogMsjComponent,
    RegExitosoComponent
  ],
  imports: [    
    HttpClientModule,
    MatButtonModule,
    MatIconModule,
    MatSidenavModule,
    MatTabsModule,
    MatInputModule,
    MatSelectModule,
    MatPaginatorModule,
    MatTableModule,
    MatSortModule,
    MatMenuModule,
    MatDialogModule,
    MatProgressSpinnerModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { 

  public appGenerales = {"user":''};
}
